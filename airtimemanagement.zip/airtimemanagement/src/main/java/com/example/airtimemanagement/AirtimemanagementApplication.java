package com.example.airtimemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirtimemanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirtimemanagementApplication.class, args);
	}

}
